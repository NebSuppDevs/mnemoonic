package com.PurpStellar.mnemoonic;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private LinearLayout main_linear;
	private TextView title;
	private LinearLayout linear2;
	private Button agree_btn;
	private TextView msg_text;
	private TextView terms_link;
	
	private Intent terms_intent = new Intent();
	private Intent goToApp_intent = new Intent();
	private SharedPreferences local_storage;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		main_linear = findViewById(R.id.main_linear);
		title = findViewById(R.id.title);
		linear2 = findViewById(R.id.linear2);
		agree_btn = findViewById(R.id.agree_btn);
		msg_text = findViewById(R.id.msg_text);
		terms_link = findViewById(R.id.terms_link);
		local_storage = getSharedPreferences("mnemoonic", Activity.MODE_PRIVATE);
		
		agree_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				local_storage.edit().putString("AgreedToTerms", "jmp").commit();
				goToApp_intent.setClass(getApplicationContext(), MainPgActivity.class);
				startActivity(goToApp_intent);
			}
		});
		
		terms_link.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				terms_intent.setClass(getApplicationContext(), PrivacyPolicyActivity.class);
				startActivity(terms_intent);
			}
		});
	}
	
	private void initializeLogic() {
		if (local_storage.getString("AgreedToTerms", "").contains("jmp")) {
			goToApp_intent.setClass(getApplicationContext(), MainPgActivity.class);
			startActivity(goToApp_intent);
		}
		else {
			
		}
	}
	
}