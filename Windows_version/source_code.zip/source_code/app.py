import webview
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
index_path = os.path.join(current_dir, "index.html")
icon_path = os.path.join(current_dir, "app_icon.ico")

def inject_navigation(window):
    """Injects the back button."""
    js_logic = """
    (function() {
        var path = window.location.pathname;
        var isIndex = path.endsWith('index.html') || path === '/' || path === '';
        
        var oldBtn = document.getElementById('pywebview-back-btn');
        if (oldBtn) oldBtn.remove();

        if (!isIndex) {
            var btn = document.createElement('div');
            btn.id = 'pywebview-back-btn';
            btn.innerHTML = '←';
            Object.assign(btn.style, {
                position: 'fixed', top: '20px', left: '20px',
                width: '50px', height: '50px',
                backgroundColor: 'rgba(191, 39, 245, 0.8)', backdropFilter: 'blur(10px)',
                color: 'white', borderRadius: '50%',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '24px', cursor: 'pointer', zIndex: '2147483647',
                boxShadow: '0 4px 15px rgba(0,0,0,0.5)', border: '1px solid rgba(255,255,255,0.1)',
                userSelect: 'none'
            });
            btn.onclick = function() { history.back(); };
            document.body.appendChild(btn);
        }
    })();
    """
    window.evaluate_js(js_logic)

window = webview.create_window(
    'mnemoonic', 
    index_path, 
    width=900, 
    height=700, 
    resizable=False
)

window.events.loaded += lambda: inject_navigation(window)

if __name__ == '__main__':
    webview.start(
        icon=icon_path, 
        http_server=True, 
        debug=False
    )
